多彩音乐 —— Colorful Music
==========================

项目简介
--------

本项目为西电国创项目，旨在基于人类对颜色、情感以及音乐的认知，建立一套音乐推荐系统。
本项目总共分算法、后端、前段三部分：

- **算法**：以机器学习与数字信号处理技术为基础，实现自动化分类算法
- **后端**：基于强大的`Java`语言搭建Web后端
- **前段**：包括*网站*、*客户端*两部分，以实现更好的用户体验

> 注意！本项目目前仍处在研发阶段，还属于原型版本。

开发须知
--------

### 数据库配置

使用前先在MySQL数据库中建立数据库，名字为`colorful_music`；并执行如下SQL语句以建立表`train_music`: 

~~~sql
CREATE DATABASE colorful_music;
USE colorful_music;
CREATE TABLE train_music(
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    url VARCHAR(255) NOT NULL UNIQUE COMMENT '音乐文件路径',
    emotion TINYINT NOT NULL DEFAULT 0 COMMENT '音乐情感标签',
    features TEXT NOT NULL COMMENT '音频特征向量',
    Primary key(id)
);
~~~

*注：`features`字段储存音频的特征向量，格式为`feature_1|feature_2|...|feature_n`，其中每一特征值
都是浮点小数。*

相关数据库的连接信息可在`Resource/Preferences.xml`文件中看到，默认的用户名为`root`，密码为`root`。
你可以根据自己需要修改`Resource/Preferences.xml`文件来设置`用户名`、`密码`、`数据库名`、`表名`。

### 使用须知

1. 执行提取操作时，注意前后不要选择相同的音乐文件，因为数据库中音乐的 URL 被标记被 unique
(不可重复)。如果需要再次提取，先删除数据库中对应 URL 的音乐，或者改变该音乐的 URL(为保证数
据的唯一性，推荐先在数据库中删除会重复 URL 的音乐)。提取的算法来自维也纳科技大学的开源项目
[MIR](http://www.ifs.tuwien.ac.at/mir/audiofeatureextraction-java/)

2. 执行训练操作时，使用的算法为SVM，在此我们选用开源项目[LibSVM](http://www.csie.ntu.edu.tw/~cjlin/libsvm/)。
这意味着你需要准备 LibSVM 需要的特征文件的格式。关于 LibSVM 的文件格式和训练时可选取的参数可以参考
`Resource/libsvm-help.md`文件。
训练前你需要做的是先从数据库中取出要训练音乐的相关信息，然后再以 LibSVM 要求的格式保存到
文件中，然后在训练界面选择该文件；建立一个文件用来保存训练模型，并在 训练界面中选择它。
如果你很懒，你可以点击训练界面的显示训练文件的输入框，它会提示你输入训练文件的名字，然后
帮你从数据库中取出数据并格式化成 LibSVM 数据格式。

3. 执行预测操作时，预测的结果会保存在你选择保存在你选择的 “结果文件”中，所以提前建立好它，
并在预测界面选择它，结果的格式为 “情感 <= 音乐路径”。结果文件应该用支持 UTF-8 的编辑器打开，
因为LibSVM Java版保存时换行符是'\n'而不是'\r\n'。

最后，由于在 Linux 操作系统上我们暂时不能设置系统的默认皮肤，所以本项目使用了 Java 的开源皮肤包
Substance，使得在不同操作系统上程序界面的外观可以较美观和一致。在本程序中提供了10种 Substance
皮肤的选项，可以在源码 Main.java 中进行选择。

Copyright & LICENSE
-------------------

Copyright &copy; 2013-2015 ColorfulMusic Team, Xidian University, Xi'an China.

Code released Under the Apache2 [LICENSE](LICENSE).
