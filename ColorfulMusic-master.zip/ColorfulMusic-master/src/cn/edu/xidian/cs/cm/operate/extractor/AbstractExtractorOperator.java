package cn.edu.xidian.cs.cm.operate.extractor;

import at.tuwien.ifs.feature.extraction.audio.data.FeatureExtractionOptions;
import cn.edu.xidian.cs.cm.operate.util.Music;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.log4j.Logger;

public abstract class AbstractExtractorOperator extends Observable {
	private static final Logger logger = Logger
			.getLogger(AbstractExtractorOperator.class);

	protected List<Music> musicList; // 需要被提取特征向量的音频文件列表
	protected ExecutorService extractThreadPool; // 提取的线程池

	private final FeatureExtractionOptions options = new FeatureExtractionOptions();

	protected AbstractExtractorOperator(ExtractionParameters parameters) {
		initExtractorOptions(parameters);
	}

	private void initExtractorOptions(ExtractionParameters parameters) {
		List<File> fileList = parameters.getFileList();
		musicList = new ArrayList<>(fileList.size());
		for (File file : fileList) {
			musicList.add(new Music(file.getAbsolutePath()));
		}
		extractThreadPool = Executors.newFixedThreadPool(parameters.getThreadCount());

		/**
		 * 提取的特征向量为 SSD
		 * 可通过设置不同的值来提取不同类型的特征向量：
		 * RH : Rhythm Histogram
		 * RP : Rhythm Patterns
		 * SSD : Statistical Spectrum Descriptor
		 * 更多可访问 http://www.ifs.tuwien.ac.at/mir/audiofeatureextraction.html
		 * 在本程序中，确保extractRH，extractRP，extractSSD 有且只有其中的一种被赋值为 true
		 */
		options.extractRH = false;
		options.extractRP = false;
		options.extractSSD = false;
		switch (parameters.getType()) {
			case SSD:
				options.extractSSD = true;
				break;
			case RH:
				options.extractRH = true;
				break;
			case RP:
				options.extractRP = true;
				break;
			default:
				break;
		}
		
		options.writeOSIRIS = false;
		options.writeSOMLib = false;
		options.writeWekaARFF = false;
		options.writeXML = true;
	}
	/**
	 * 开始对音频文件列表中的音频进行特征向量的提取
	 */
	public void start() {
		List<AudioFeatureExtractor> extractors = new ArrayList<>(
				musicList.size());
		for (Music music : musicList) {
			extractors.add(new AudioFeatureExtractor(music.getUrl(), options));
		}

		List<Future<double[]>> results = new ArrayList<>(musicList.size());
		for (AudioFeatureExtractor extractor : extractors) {
			results.add(extractThreadPool.submit(extractor));
		}
		extractThreadPool.shutdown(); // 不再接收任务，当前池中的任务等待完成

		int index = 0;
		boolean failed;
		for (Future<double[]> result : results) {
			failed = true;
			try {
				double[] features = result.get(13, TimeUnit.SECONDS); // 设置超时时间为
																		// 10 秒
				musicList.get(index).setFeatures(features);
				failed = false;
			} catch (InterruptedException ex) {
				logger.error(musicList.get(index).getUrl() + "提取被中断");
			} catch (ExecutionException ex) {
				logger.error(musicList.get(index).getUrl() + "提取时出错");
			} catch (TimeoutException ex) {
				logger.error(musicList.get(index).getUrl() + "提取超时");
			}
			if (failed) {
				result.cancel(true); // 如果失败便取消任务
				musicList.get(index).setFeatures(null);
			}
			index++;
			updataFrameUI(index);
		}

		doTask();
	}
	/**
	 * 使用观察者模式通知观察者（界面类）
	 * @param status
	 */
	protected abstract void updataFrameUI(Object arg);

	/**
	 * 在这个方法里决定提取出的音乐的特征是<br> 
	 * 保存到数据库中用于训练 还是 直接用于预测，在子类中实现
	 */
	protected abstract void doTask();
}
