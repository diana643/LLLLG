package cn.edu.xidian.cs.cm.operate.util;

public enum FeatureType {
	SSD, RH, RP
}
