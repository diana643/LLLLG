package cn.edu.xidian.cs.cm.operate.train;

import java.io.IOException;
import java.util.Observable;
import org.apache.log4j.Logger;

/**
 * 使用 LibSVM算法的训练类
 * @author ColorfulMusic Team
 *
 */
public class LibSVMTrainer extends Observable implements Trainer{
    private static final Logger logger = Logger.getLogger(LibSVMTrainer.class);
    private final String[] trainParameters;

    public LibSVMTrainer(String[] trainParameters) {
        this.trainParameters = trainParameters;
    }
    
    @Override
    public void train() {
    
        try {
            SVMTrain.train(trainParameters);
        } catch (IOException ex) {
            logger.error("训练时出错，请检查参数");
        }
        updateTrainFrameUI();
    }
    
    private void updateTrainFrameUI(){
        notifyObservers();
    }
    
    @Override
    public void notifyObservers() {
        super.notifyObservers();
    }
    
}
