package cn.edu.xidian.cs.cm.operate.predict;

import cn.edu.xidian.cs.cm.operate.extractor.ExtractionParameters;

import java.io.File;
import java.util.List;

/**
 * 预测时的 预测参数<br>
 * 预测时需要先提取音频的特征向量，所以预测参数包含了提取参数和 LibSVM 需要的预测参数
 * @author ColorfulMusic Team
 *
 */
public class PredictParameters extends ExtractionParameters{
    
    private String[] svmParameters ;

    public PredictParameters(List<File> fileList, String[] svmParameters, int threadCount){
        this(fileList, svmParameters, threadCount, 0);
    }
    private PredictParameters(List<File> fileList,String[] svmParameters, int threadCount, int emotionInDB) {
        super(fileList, threadCount, emotionInDB);
        this.svmParameters = svmParameters;
    }

    public String[] getSvmParameters() {
        return svmParameters;
    }

    public void setSvmParameters(String[] svmParameters) {
        this.svmParameters = svmParameters;
    }
    
}
