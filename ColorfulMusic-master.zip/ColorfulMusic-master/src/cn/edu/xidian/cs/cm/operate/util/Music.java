package cn.edu.xidian.cs.cm.operate.util;

import java.io.Serializable;
import java.util.Objects;

public class Music implements Serializable {

    private static final long serialVersionUID = 20140822;

    private String url; //
    private String name; //
    private String artist; //
    private String album; //
    private String year; // 年份
    private int duration; //
    private Emotion emotion; //
    
    private double[] features;

    public double[] getFeatures() {
        return features;
    }

    public void setFeatures(double[] features) {
        this.features = features;
    }

    public Music(){
        
    }
    public Music (String url){
        this("", url);
    }
    public Music(String name, String url) {
        this(name, url, Emotion.Unkonwn);
    }

    public Music(String name, String url, Emotion emotion) {
        this(name, url, "", "", 0, emotion);
    }

    public Music(String name, String url, String artist, String album, int duration, Emotion emotion) {
        this.name = name;
        checkUrl(url);
        this.artist = artist;
        this.album = album;
        this.duration = duration;
        this.emotion = emotion;
    }
    private void checkUrl(String url){
        this.url = url.replace('\\', '/');
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
    public Emotion getEmotion() {
        return emotion;
    }

    public void setEmotion(Emotion emotion) {
        this.emotion = emotion;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Music)){
            return false;
        }
        return this.url.equals(((Music) obj).getUrl());
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.url);
        return hash;
    }

    @Override
    public String toString() {
        return "Music [url=" + url + ", name=" + name + "]";
    }
}
