package cn.edu.xidian.cs.cm.operate.util;

public enum Emotion {
	Happy, Sad, Peace, Excited, Unkonwn;
}
