package cn.edu.xidian.cs.cm.operate.predict;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.log4j.Logger;

import cn.edu.xidian.cs.cm.operate.extractor.AbstractExtractorOperator;
import cn.edu.xidian.cs.cm.operate.util.CMPreferences;
import cn.edu.xidian.cs.cm.operate.util.Music;

public class ExtractorOpetratorForPredict extends AbstractExtractorOperator implements Predictor{
    private static final Logger logger = Logger.getLogger(ExtractorOpetratorForPredict.class);
    
    private final String[] svmParameters;
    private final String resultsFilePath;
    	
    public ExtractorOpetratorForPredict(PredictParameters parameters) {
        super(parameters);
        svmParameters = parameters.getSvmParameters();
        resultsFilePath = svmParameters[svmParameters.length - 1];
        svmParameters[svmParameters.length - 1] = CMPreferences.TMP_RESULTS_FILE; // 先将LibSVM格式的结果保存在临时文件里
    }

    @Override
    protected void doTask() {
        try {
            try ( // 保存要预测音乐的向量到文件
                BufferedWriter libSVMWriter = new BufferedWriter(new FileWriter(CMPreferences.TMP_FEATURES_FILE), 1024)) {
                updataFrameUI("正在预测 ...");
                
                StringBuilder featuresBuilder = new StringBuilder();
                for (Music music : musicList){
                    featuresBuilder.delete(0, featuresBuilder.length());
                    
                    featuresBuilder.append("0 ");
                    double[] features = music.getFeatures();
                    int n = 1;
                    for (double feature : features){
                        featuresBuilder.append(n);
                        featuresBuilder.append(":");
                        featuresBuilder.append(feature);
                        featuresBuilder.append(" ");
                        n++;
                    }
                    featuresBuilder.setCharAt(featuresBuilder.length()-1, '\n');
                    
                    libSVMWriter.write(featuresBuilder.toString());
                    libSVMWriter.flush();
                }
                predict();
                
                transferResultFile();
            }
        } catch (IOException ex) {
            logger.error("ExtractorOpetratorForPredict doTask() 时出错");
        }
    }

    @Override
    protected void updataFrameUI(Object arg) {
        setChanged();
        notifyObservers(arg);
    }

    @Override
    public void predict() {
        try {
            SVMPredict.predict(svmParameters);
        } catch (IOException ex) {
            logger.error("使用LibSVM预测时出错");
        }
    }
    /**
     * 将LibSVM的结果文件转化为更清楚的结果文件(情感 <= 音乐URL)
     */
    public void transferResultFile() {
		File resultFile = new File(svmParameters[svmParameters.length-1]);
		if (resultFile.exists()){
			try (
				BufferedReader resultsReader = new BufferedReader(new FileReader(CMPreferences.TMP_RESULTS_FILE))){
				StringBuilder resultsBuilder = new StringBuilder();
				
				String result = null;
				for (Music music : musicList){
					try {
						result = resultsReader.readLine();
						switch (result) {
							case "1.0":
								resultsBuilder.append("快乐");
								break;
							case "2.0":
								resultsBuilder.append("平静");
								break;
							case "3.0":
								resultsBuilder.append("振奋");
								break;
							case "4.0":
								resultsBuilder.append("悲伤");
								break;
							default:
								resultsBuilder.append("未知");
								break;
						}
						resultsBuilder.append(" <= ");
						resultsBuilder.append(music.getUrl());
						resultsBuilder.append('\n');
					} catch (IOException e) {
						logger.error(music.getUrl() + " 写入结果时出错");
					}
				}
				
				try (
					BufferedWriter resultsWriter = new BufferedWriter(new FileWriter(resultsFilePath))){
					resultsWriter.write(resultsBuilder.toString());
					resultsWriter.flush();
				} catch (IOException e) {
					logger.error("resultsWriter 向结果文件中写入出错");
				}
			} catch (IOException e) {
				logger.error("没有找到 Results.tmp 文件");
			}
		}
	}
}