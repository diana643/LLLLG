package cn.edu.xidian.cs.cm.operate.predict;

public interface Predictor {
    
	/**
	 * 根据音频特征向量对音频的情感进行预测
	 */
    public void predict();
}
