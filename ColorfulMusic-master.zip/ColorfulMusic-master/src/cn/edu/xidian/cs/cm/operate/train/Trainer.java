package cn.edu.xidian.cs.cm.operate.train;

public interface Trainer {
	/**
	 * 对给定的特征向量进行训练并获得模型
	 */
    public void train();
}
