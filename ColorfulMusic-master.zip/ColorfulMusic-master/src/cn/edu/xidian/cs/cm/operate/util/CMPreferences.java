package cn.edu.xidian.cs.cm.operate.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentFactory;
import org.dom4j.Element;
import org.dom4j.VisitorSupport;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class CMPreferences {
	private static final Logger logger = Logger.getLogger(CMPreferences.class);

	// <editor-fold defaultstate="collapsed" desc="单例模式，保证 CMPropt 在单线程和多线程环境中只有一个实例">
	private static class CMPreferencesClass {
		private static final CMPreferences instance = new CMPreferences();
	}

	public static CMPreferences getInstance() {
		return CMPreferencesClass.instance;
	}

	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="使用访问者模式访问 xml 文件">
	private CMPreferences() {
		logger.info("初始化 CMPreferences");
		initFields();
		File preferenceFile = new File(PREFERENCES_FILE);
		if (preferenceFile.exists()) {
			SAXReader xmlReader = new SAXReader();
			xmlReader.setIgnoreComments(true);
			try {
				Document xmlDoc = xmlReader.read(new File(PREFERENCES_FILE));
				xmlDoc.accept(new PreferencesVisitor());
			} catch (DocumentException ex) {
				logger.error("读取 Preferences.xml 文件时出错");
				ex.printStackTrace();
			}
		} else {
			save();
		}
	}

	class PreferencesVisitor extends VisitorSupport {

		@Override
		public void visit(Element node) {

			switch (node.getName()) {
			case "MusicFileChooserStartPath":
				musicFileChooserStartPath = node.getTextTrim();
				break;
			case "DefaultFileChooserStartPath":
				defaultFileChooserStartPath = node.getTextTrim();
				break;
			case "DBDriver":
				DBDriver = node.getTextTrim();
				break;
			case "DBUrl":
				DBUrl = node.getTextTrim();
				break;
			case "DBTable":
				DBTable = node.getTextTrim();
				break;
			case "DBUserName":
				DBUserName = node.getText();
				break;
			case "DBPassword":
				DBPassword = node.getTextTrim();
				break;
			}
		}

	}

	// </editor-fold>

	public final void save() {
		DocumentFactory documentFactory = DocumentFactory.getInstance();
		Document xmlDoc = documentFactory.createDocument();

		Element rootElement = xmlDoc.addElement("ColorfulMusic");
		rootElement.addAttribute("url",
				"http://www.github.com/ZMichealChow/ColorfulMusic");

		Element dataBaseInfoElement = rootElement.addElement("DatabaseInfo");
		dataBaseInfoElement.addElement("DBDriver").setText(DBDriver);
		dataBaseInfoElement.addElement("DBUrl").setText(DBUrl);
		dataBaseInfoElement.addElement("DBTable").setText(DBTable);
		dataBaseInfoElement.addElement("DBUserName").setText(DBUserName);
		dataBaseInfoElement.addElement("DBPassword").setText(DBPassword);

		Element fileStartPathElement = rootElement.addElement("FileStartPath");
		fileStartPathElement.addElement("MusicFileChooserStartPath").setText(
				musicFileChooserStartPath);
		fileStartPathElement.addElement("DefaultFileChooserStartPath").setText(
				defaultFileChooserStartPath);

		XMLWriter xmlWriter = null;
		try {
			xmlWriter = new XMLWriter(new FileWriter(PREFERENCES_FILE),
					OutputFormat.createPrettyPrint());
			xmlWriter.write(xmlDoc);
		} catch (IOException ex) {
			logger.error("保存 Preferences 文件时出错");
		} finally {
			if (xmlWriter != null) {
				try {
					xmlWriter.close();
				} catch (IOException ex) {
					logger.error("关闭 Preferences 文件时出错");
				}
			}
		}
	}

	private void initFields() {
		musicFileChooserStartPath = "";
		defaultFileChooserStartPath = "";
		DBDriver = "";
		DBUrl = "";
		DBUserName = "";
		DBPassword = "";
		DBTable = "";
	}

	private String musicFileChooserStartPath;
	private String defaultFileChooserStartPath;

	private String DBDriver;
	private String DBUrl;
	private String DBTable;
	private String DBUserName;
	private String DBPassword;

	public String getDBTable() {
		return DBTable;
	}

	public String getDBDriver() {
		return DBDriver;
	}

	public String getDBUrl() {
		return DBUrl;
	}

	public String getDBUserName() {
		return DBUserName;
	}

	public String getDBPassword() {
		return DBPassword;
	}

	public String getDefaultFileChooserStartPath() {
		return defaultFileChooserStartPath;
	}

	public void setDefaultFileChooserStartPath(
			String defaultFileChooserStartPath) {
		this.defaultFileChooserStartPath = defaultFileChooserStartPath;
	}

	public String getMusicFileChooserStartPath() {
		return musicFileChooserStartPath;
	}

	public void setMusicFileChooserStartPath(String musicFileChooserStartPath) {
		this.musicFileChooserStartPath = musicFileChooserStartPath;
	}

	private static final String PREFERENCES_FILE = "Resource/Preferences.xml";

	public static final char SEPARATOR = '|';
	public static final String TMP_FEATURES_FILE = "TempFiles/Features.tmp";
	public static final String TMP_RESULTS_FILE = "TempFiles/Results.tmp";
	public static final String TMP_FILE_DIR = "TempFiles/";
	public static String NotSelectPath = "尚未选择任何文件";
	public static String ExtractionStatus = "提取状态：";
	public static String WaitingForExtraction = "等待提取：";
	public static String DuringExtraction = "正在提取：";
	public static String SelectedMusicFiles = "选中的音乐文件";
	public static String DuringExtractionPrompt = "当前操作不可用，请等待提取完毕";
}
