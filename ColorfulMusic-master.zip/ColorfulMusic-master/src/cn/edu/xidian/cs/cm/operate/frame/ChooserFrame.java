package cn.edu.xidian.cs.cm.operate.frame;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class ChooserFrame extends AbstractOperateFrame {
	private static final long serialVersionUID = 20141001L;
	
    @Override
    protected void initComponent() {

        promptLabel = new JLabel("请选择以下操作中的一项：");

        operateButtonGroup = new ButtonGroup();
        extractRadioButton = new JRadioButton("提取");
        extractRadioButton.setFocusPainted(false);
        extractRadioButton.setSelected(true);
        trainRadioButton = new JRadioButton("训练");
        trainRadioButton.setFocusPainted(false);
        predictRadioButton = new JRadioButton("预测");
        predictRadioButton.setFocusPainted(false);
        operateButtonGroup.add(extractRadioButton);
        operateButtonGroup.add(trainRadioButton);
        operateButtonGroup.add(predictRadioButton);

        JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel1.add(promptLabel);

        JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 3, 0));
        panel2.add(extractRadioButton);
        panel2.add(trainRadioButton);
        panel2.add(predictRadioButton);

        operateButton.setText("确定");
        JPanel panel3 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        panel3.add(operateButton);
        panel3.add(exitButton);

        addComponentToMainBox(panel1, panel2, panel3);
        mainBox.setPreferredSize(new Dimension(320, 160));

        setTitle("选择操作");
        
    }

    @Override
    protected void addListener() {
        operateButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                Enumeration<AbstractButton> radioButtons = operateButtonGroup.getElements();
                String operateOption = "";
                while (radioButtons.hasMoreElements()) {
                    JRadioButton radioButton = (JRadioButton) radioButtons.nextElement();
                    if (radioButton.isSelected()) {
                        operateOption = radioButton.getText();
                        break;
                    }
                }
                ChooserFrame.this.setVisible(false);
                switch (operateOption) {
                    case "提取":
                        new ExtractorFrame().setVisible(true);
                        break;
                    case "训练":
                        new TrainerFrame().setVisible(true);
                        break;
                    case "预测":
                        new PredictorFrame().setVisible(true);
                        break;
                }
                ChooserFrame.this.dispose();
            }
        });

        exitButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                ChooserFrame.this.dispose();
            }
        });
    }

    private JLabel promptLabel;
    private JRadioButton extractRadioButton;
    private JRadioButton trainRadioButton;
    private JRadioButton predictRadioButton;
    private ButtonGroup operateButtonGroup;

}
