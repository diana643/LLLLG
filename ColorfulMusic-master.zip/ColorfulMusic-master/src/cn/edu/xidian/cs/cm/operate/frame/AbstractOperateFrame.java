package cn.edu.xidian.cs.cm.operate.frame;

import cn.edu.xidian.cs.cm.operate.util.CMPreferences;

import java.awt.Component;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

/**
 * 抽象操作界面，封装了本程序所有界面的基本结构和一些通用方法
 * @author ColorfulMusic Team
 *
 */
public abstract class AbstractOperateFrame extends JFrame{
	private static final long serialVersionUID = 20141001L;
	
	protected static final int CPU_COUNT = Runtime.getRuntime().availableProcessors();
    protected static CMPreferences cmPreferences = CMPreferences.getInstance();
    protected static final int margin = 20;
    protected static final int padding = 15;
    
    protected boolean isInOperation ;
    protected Box mainBox ;
    protected JButton operateButton ;
    protected JButton exitButton;
    protected JLabel statusLabel;
    
    protected AbstractOperateFrame(){
        isInOperation = false;
        operateButton = new JButton("开始");
        exitButton = new JButton("退出");
        statusLabel = new JLabel("初始状态");
        mainBox = Box.createVerticalBox();
        
        initFrame();
        
        this.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                exitButton.doClick();
            }
        });
    }
    private void initFrame(){
        initComponent();
        addListener();
        
        this.add(new JScrollPane(mainBox));
        this.setResizable(false);
        this.setIconImage(new ImageIcon(
        		ClassLoader.getSystemResource("icon/icon.png")).getImage());
        this.pack();
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
    }
    /**
     * 初始化界面组件
     */
    protected abstract void initComponent();
    
    /**
     * 为界面组件添加监听事件
     */
    protected abstract void addListener();
    
    /**
     * 完成一次任务后更新数据和界面
     */
    protected void reflushUIAndData(){}
    
    /**
     * 将一些界面组件按从上到下的方式添加到主面板
     * @param components 一些界面组件
     */
    protected void addComponentToMainBox(Component ... components){
        for (Component component : components){
            mainBox.add(Box.createVerticalStrut(padding));
            mainBox.add(component);
        }
        mainBox.add(Box.createVerticalStrut(padding));
    }
    /**
     * 打开文件选择对话框
     * @return 被选中文件的路径，如果没有选择则返回一个空字符串
     */
    protected String launchSelectFileDialog(){
        JFileChooser fileChooser = new JFileChooser(cmPreferences.getDefaultFileChooserStartPath());
        fileChooser.setMultiSelectionEnabled(false);
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int option = fileChooser.showSaveDialog(this);
        if (option == JFileChooser.APPROVE_OPTION){
            cmPreferences.setDefaultFileChooserStartPath(fileChooser.getSelectedFile().getParent());
            cmPreferences.save();
            return fileChooser.getSelectedFile().getAbsolutePath();
        }
        return "";
    }
    /**
     * 提取出目录下所有的特定文件
     * @param dir 目录路径
     * @param extension 文件后缀
     * @return 提取出的文件列表
     */
    protected List<File> getSpecificFiles(File dir, String extension){
        return getSpecificFiles(dir.listFiles(), extension);
    }
    /**
     * 提取出文件数组中所有的特定文件
     * @param files 文件数组
     * @param extension 文件后缀
     * @return 提取出的文件列表
     */
    protected List<File> getSpecificFiles(File[] files, String extension){
        List<File> fileList = new ArrayList<>();
        for (File file : files){
            if (file.getAbsolutePath().toLowerCase().endsWith(extension)){
                fileList.add(file);
            }
        }
        return fileList;
    }
    protected void showMessage(String msg){
        showMessage(msg, "提示");
    }
    protected void showMessage(String msg, String title){
        JOptionPane.showMessageDialog(this, msg, title, JOptionPane.INFORMATION_MESSAGE);
    }
}
