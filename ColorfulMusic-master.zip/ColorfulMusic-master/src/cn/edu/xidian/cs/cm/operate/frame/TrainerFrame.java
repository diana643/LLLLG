package cn.edu.xidian.cs.cm.operate.frame;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import cn.edu.xidian.cs.cm.operate.train.LibSVMTrainer;
import cn.edu.xidian.cs.cm.operate.train.Trainer;
import cn.edu.xidian.cs.cm.operate.util.CMPreferences;
import cn.edu.xidian.cs.cm.operate.util.DBConnectionProvider;

public class TrainerFrame extends AbstractOperateFrame implements Observer{
	private static final long serialVersionUID = 20141001L;
	private static final Logger logger = Logger.getLogger(TrainerFrame.class);
    
    @Override
    public void update(Observable o, Object arg) {
        if (o instanceof LibSVMTrainer){
            // 暂时不做处理
        }
    }
    
    // <editor-fold defaultstate="collapsed" desc="初始化界面">
    @Override
    protected void initComponent(){
        
        trainFileDescLabel = new JLabel("训练文件：");
        trainFileTextField = new JTextField(CMPreferences.NotSelectPath);
        trainFileTextField.setEditable(false);
        chooseTrainFileButton = new JButton("选择");
        Box box1 = Box.createHorizontalBox();
        box1.add(Box.createHorizontalStrut(margin));
        box1.add(trainFileDescLabel);
        box1.add(trainFileTextField);
        box1.add(Box.createHorizontalStrut(padding));
        box1.add(chooseTrainFileButton);
        box1.add(Box.createHorizontalStrut(margin));
        
        trainParameterDescLabel = new JLabel("训练参数：");
        trainParameterTextField = new JTextField("-s 0 -t 1");
        trainParameterTextField.setPreferredSize(new Dimension(340, 20));
        Box box2 = Box.createHorizontalBox();
        box2.add(Box.createHorizontalStrut(margin));
        box2.add(trainParameterDescLabel);
        box2.add(trainParameterTextField);
        box2.add(Box.createHorizontalStrut(margin));
        
        modelDescLabel = new JLabel("保存模型：");
        modelFileTextField = new JTextField(CMPreferences.NotSelectPath);
        modelFileTextField.setEditable(false);
        chooseModelFileButton = new JButton("选择");
        Box box3 = Box.createHorizontalBox();
        box3.add(Box.createHorizontalStrut(margin));
        box3.add(modelDescLabel);
        box3.add(modelFileTextField);
        box3.add(Box.createHorizontalStrut(padding));
        box3.add(chooseModelFileButton);
        box3.add(Box.createHorizontalStrut(margin));
        
        operateButton.setText("训练");
        JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.RIGHT, margin, 0));
        panel1.add(statusLabel);
        panel1.add(Box.createHorizontalGlue());
        panel1.add(operateButton);
        panel1.add(exitButton);
        
        addComponentToMainBox(box1, box3, box2, panel1);
        
        setTitle("训练");
        
        logger.info("启动 TrainerFrame");
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="添加监听器">
    @Override
    protected void addListener(){
        operateButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (isInOperation){
                    showMessage(CMPreferences.DuringExtractionPrompt);
                    return;
                }
                if (trainFileTextField.getText().equals(CMPreferences.NotSelectPath)){
                    showMessage("请选择要训练的文件");
                    return;
                }
                if (modelFileTextField.getText().equals(CMPreferences.NotSelectPath)){
                    showMessage("请选择要保存到的模型文件");
                    return;
                }
                if (trainParameterTextField.getText().trim().equals("")){
                    showMessage("请输入训练参数");
                    return;
                }
                String[] parameters = trainParameterTextField.getText().split(" ");
                List<String> parameterList = new ArrayList<>();
                parameterList.addAll(Arrays.asList(parameters));
                parameterList.add(trainFileTextField.getText());
                parameterList.add(modelFileTextField.getText());
                
                final String[] svmParameters = (String[])parameterList.toArray(new String[parameterList.size()]);
                
                Thread trainThread = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        isInOperation = true;
                        statusLabel.setText("正在训练...");
                        Trainer trainer = new LibSVMTrainer(svmParameters);
                        long begin = System.nanoTime();
                        
                        trainer.train();
                        
                        long end = System.nanoTime();
                        statusLabel.setText(String.format("训练完成，用时：%.2f 秒", (end-begin)/Math.pow(10, 9)));
                        reflushUIAndData();
                    }
                });
                trainThread.setDaemon(true);
                trainThread.start();
            }
        });
        
        chooseTrainFileButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedFilePath = launchSelectFileDialog();
                if (!selectedFilePath.equals("")){
                    trainFileTextField.setText(selectedFilePath);
                }
            }
        });
        
        chooseModelFileButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedFilePath = launchSelectFileDialog();
                if (!selectedFilePath.equals("")){
                    modelFileTextField.setText(selectedFilePath);
                }
            }
        });
        
        trainFileTextField.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (trainFileTextField.getText().equals(CMPreferences.NotSelectPath)){
                	int option = JOptionPane.showConfirmDialog(TrainerFrame.this, "是否从数据库中取出训练数据", "提示", JOptionPane.YES_NO_OPTION);
                	if (option == JOptionPane.YES_OPTION){
                		String trainFileName = JOptionPane.showInputDialog("请输入训练文件的名称：");
						if (trainFileName == null || trainFileName.equals("")){
							showMessage("你输入文件名为空，请想好再输入");
							return;
						}
						getTrainFileFromDB(trainFileName);
						trainFileTextField.setText(CMPreferences.TMP_FILE_DIR+trainFileName);
                	}
                } else {
                	showMessage(trainFileTextField.getText(), "选中的训练文件的路径");
                }
            }
        });
        
        modelFileTextField.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                showMessage(modelFileTextField.getText(), "选中的保存模型文件的路径");
            }
        });
        
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isInOperation){
                    showMessage(CMPreferences.DuringExtractionPrompt);
                } else {
                    TrainerFrame.this.setVisible(false);
                    new ChooserFrame().setVisible(true);
                    TrainerFrame.this.dispose();
                }
            }
        });
    }
    // </editor-fold>
    
    /**
     * 从数据库中获取要进行训练的音频的情感和特征值<br>
     * 并格式化为LibSVM需要的格式，然后保存在TempFiles/trainFileName
     * @param trainFileName LibSVM格式文件的名称
     */
    private void getTrainFileFromDB(String trainFileName){
    	statusLabel.setText("正在准备训练文件...");
    	String sql = "SELECT EMOTION,FEATURES FROM train_music";
    	DBConnectionProvider provider = DBConnectionProvider.getInstance();
    	try {
			Connection conn = provider.getConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet resultSet = stmt.executeQuery(sql);
			try {
				BufferedWriter featuresWriter = new BufferedWriter(new FileWriter(CMPreferences.TMP_FILE_DIR+trainFileName),1024);
				StringBuilder featuresBuilder = new StringBuilder();
				while (resultSet.next()){
					featuresBuilder.delete(0, featuresBuilder.length());
					int emotion = resultSet.getInt(1);
					String[] features = StringUtils.split(resultSet.getString(2), CMPreferences.SEPARATOR);
					
					featuresBuilder.append(emotion);
					int n = 1;
					for (String feature : features){
						featuresBuilder.append(' ');
						featuresBuilder.append(n);
						featuresBuilder.append(':');
						featuresBuilder.append(feature);
						n++;
					}
					featuresBuilder.append('\n');
					featuresWriter.write(featuresBuilder.toString());
					featuresWriter.flush();
				}
				featuresWriter.close();
			} catch (IOException e) {
				logger.error("向 Train.tmp 中写入时出错");
			} 
			
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			logger.error("数据库连接出错,请检查");
		}
    	statusLabel.setText("训练文件准备完毕");
    }
    @Override
    protected void reflushUIAndData() {
        isInOperation = false;
        trainFileTextField.setText(CMPreferences.NotSelectPath);
        modelFileTextField.setText(CMPreferences.NotSelectPath);
    }
    
    // <editor-fold defaultstate="collapsed" desc="界面组件">
    private JLabel trainFileDescLabel;
    private JTextField trainFileTextField;
    private JButton chooseTrainFileButton;
    
    private JLabel trainParameterDescLabel;
    private JTextField trainParameterTextField;
    
    private JLabel modelDescLabel;
    private JTextField modelFileTextField;
    private JButton chooseModelFileButton;
    
    // </editor-fold>

}
