package cn.edu.xidian.cs.cm.operate.extractor;

import java.io.File;
import java.util.List;

import cn.edu.xidian.cs.cm.operate.util.FeatureType;

/**
 * 提取时的 提取参数
 * @author ColorfulMusic Team
 *
 */
public class ExtractionParameters {
    private List<File> fileList;
    private int threadCount;
    private int emotionInDB;
    private FeatureType type;

    public FeatureType getType() {
		return type;
	}
	public void setType(FeatureType type) {
		this.type = type;
	}
	public ExtractionParameters(List<File> fileList, int threadCount, int emotionInDB) {
        this(fileList, threadCount, emotionInDB, FeatureType.SSD);
    }
    public ExtractionParameters(List<File> fileList, int threadCount, int emotionInDB, FeatureType type) {
        this.fileList = fileList;
        this.threadCount = threadCount;
        this.emotionInDB = emotionInDB;
        this.type = type;
    }

    public List<File> getFileList() {
        return fileList;
    }

    public void setFileList(List<File> fileList) {
        this.fileList = fileList;
    }
    
    public int getThreadCount() {
        return threadCount;
    }

    public void setThreadCount(int threadCount) {
        this.threadCount = threadCount;
    }

    public int getEmotionInDB() {
        return emotionInDB;
    }

    public void setEmotionInDB(int emotionInDB) {
        this.emotionInDB = emotionInDB;
    }

}
