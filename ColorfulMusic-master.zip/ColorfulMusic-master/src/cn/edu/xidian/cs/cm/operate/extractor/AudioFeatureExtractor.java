package cn.edu.xidian.cs.cm.operate.extractor;

import at.tuwien.ifs.feature.extraction.audio.AudioFileExtractor;
import at.tuwien.ifs.feature.extraction.audio.FeatureExtractorException;
import at.tuwien.ifs.feature.extraction.audio.data.FeatureExtractionOptions;
import at.tuwien.ifs.feature.extraction.audio.data.RealMatrixExt;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.Callable;

import javax.sound.sampled.UnsupportedAudioFileException;

import org.apache.log4j.Logger;

/**
 * 音频特征向量的提取器，算法来自 http://www.ifs.tuwien.ac.at/mir/audiofeatureextraction-java/
 * @author ColorfulMusic Team
 *
 */
public class AudioFeatureExtractor implements Extractor, Callable<double[]>{
	private static final Logger logger = Logger.getLogger(AudioFeatureExtractor.class);
    private final AudioFileExtractor audioFileExtractor = new AudioFileExtractor();
    private FeatureExtractionOptions options ;
    private File file;
    
    public AudioFeatureExtractor(String filePath, FeatureExtractionOptions options){
        this(new File(filePath), options);
    }
    public AudioFeatureExtractor(File file, FeatureExtractionOptions options){
        this.file = file;
        this.options = options;
    }
    
    @Override
    public double[] extract(File file) {
        try {
            RealMatrixExt[] realMatrixExt = audioFileExtractor.extractAudioFile(file, options);
            
            return realMatrixExt[0].vectorize();
        } catch (UnsupportedAudioFileException | IOException | FeatureExtractorException ex) {
            logger.error("提取 " + file.getAbsolutePath() + " 出错");
            return null;
        }
    }

    @Override
    public double[] call() throws Exception {
        return extract(file);
    }
}
