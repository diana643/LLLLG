package cn.edu.xidian.cs.cm.operate.extractor;

import java.io.File;

public interface Extractor {
    
	/**
	 * 从音频文件中提取出音频特征向量
	 * @param file 音频文件
	 * @return 音频特征向量
	 */
    public double[] extract(File file);
    
}
