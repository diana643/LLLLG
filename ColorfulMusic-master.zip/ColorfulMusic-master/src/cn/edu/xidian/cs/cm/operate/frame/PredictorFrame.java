package cn.edu.xidian.cs.cm.operate.frame;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import cn.edu.xidian.cs.cm.operate.predict.ExtractorOpetratorForPredict;
import cn.edu.xidian.cs.cm.operate.predict.PredictParameters;
import cn.edu.xidian.cs.cm.operate.util.CMPreferences;

public class PredictorFrame extends AbstractOperateFrame implements Observer {
	private static final long serialVersionUID = 20141001L;
	private static final Logger logger = Logger.getLogger(PredictorFrame.class);

	private int taskCount = 0;
	private String allMusicFilePaths;

	@Override
	public void update(Observable o, Object arg) {
		if (o instanceof ExtractorOpetratorForPredict) {
			if (arg instanceof Integer) {
				int finishedTaskCount = (Integer) arg;
				statusLabel.setText(String.format("正在提取向量：%d/%d",
						finishedTaskCount, taskCount));
			} else if (arg instanceof String) {
				statusLabel.setText(arg.toString());
			}
		}
	}

	// <editor-fold defaultstate="collapsed" desc="初始化界面">
	@Override
	protected void initComponent() {

		chooseFileSourceLabel = new JLabel("请选择音乐源类型：");
		chooseFolderRadioButton = new JRadioButton("文件夹");
		chooseFolderRadioButton.setFocusPainted(false);
		chooseFilesRadioButton = new JRadioButton("若干文件");
		chooseFilesRadioButton.setFocusPainted(false);
		chooseFilesRadioButton.setSelected(true);
		fileSourceButtonGroup = new ButtonGroup();
		chooseFileSourceButton = new JButton("选择");
		fileSourceButtonGroup.add(chooseFolderRadioButton);
		fileSourceButtonGroup.add(chooseFilesRadioButton);

		threadCountDescLabel = new JLabel("开启的线程数：");
		Integer[] threadCounts = new Integer[CPU_COUNT + 1];
		for (int i = 0; i < threadCounts.length; i++) {
			threadCounts[i] = i + 1;
		}
		threadCountComboBox = new JComboBox<Integer>(threadCounts);
		threadCountComboBox.setSelectedIndex(CPU_COUNT - 1);

		Box box1 = Box.createHorizontalBox();
		box1.add(Box.createHorizontalStrut(margin));
		box1.add(chooseFileSourceLabel);
		box1.add(chooseFolderRadioButton);
		box1.add(chooseFilesRadioButton);
		box1.add(Box.createHorizontalStrut(margin));
		box1.add(threadCountDescLabel);
		box1.add(threadCountComboBox);
		box1.add(Box.createHorizontalStrut(margin));

		musicSourceDescLabel = new JLabel("预测音乐：");
		musicSourceTextField = new JTextField(CMPreferences.NotSelectPath);
		musicSourceTextField.setEditable(false);
		musicSourceTextField.setPreferredSize(new Dimension(200, 20));
		Box box2 = Box.createHorizontalBox();
		box2.add(Box.createHorizontalStrut(margin));
		box2.add(musicSourceDescLabel);
		box2.add(musicSourceTextField);
		box2.add(Box.createHorizontalStrut(padding));
		box2.add(chooseFileSourceButton);
		box2.add(Box.createHorizontalStrut(margin));

		modelFileDescLabel = new JLabel("选择模型：");
		modelFileTextField = new JTextField(CMPreferences.NotSelectPath);
		modelFileTextField.setEditable(false);
		chooseModelFileButton = new JButton("选择");
		Box box3 = Box.createHorizontalBox();
		box3.add(Box.createHorizontalStrut(margin));
		box3.add(modelFileDescLabel);
		box3.add(modelFileTextField);
		box3.add(Box.createHorizontalStrut(padding));
		box3.add(chooseModelFileButton);
		box3.add(Box.createHorizontalStrut(margin));

		trainParameterDescLabel = new JLabel("训练参数：");
		trainParameterTextField = new JTextField();
		trainParameterTextField.setPreferredSize(new Dimension(340, 20));
		Box box4 = Box.createHorizontalBox();
		box4.add(Box.createHorizontalStrut(margin));
		box4.add(trainParameterDescLabel);
		box4.add(trainParameterTextField);
		box4.add(Box.createHorizontalStrut(margin));

		resultFileDescLabel = new JLabel("保存结果：");
		resultFileTextField = new JTextField(CMPreferences.NotSelectPath);
		resultFileTextField.setEditable(false);
		chooseResultFileButton = new JButton("选择");
		Box box5 = Box.createHorizontalBox();
		box5.add(Box.createHorizontalStrut(margin));
		box5.add(resultFileDescLabel);
		box5.add(resultFileTextField);
		box5.add(Box.createHorizontalStrut(padding));
		box5.add(chooseResultFileButton);
		box5.add(Box.createHorizontalStrut(margin));

		operateButton.setText("预测");
		JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.RIGHT, margin, 0));
		panel1.add(statusLabel);
		panel1.add(operateButton);
		panel1.add(exitButton);

		addComponentToMainBox(box1, box2, box3, box5, box4, panel1);

		setTitle("预测");

		logger.info("启动 PredictorFrame");
	}

	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="添加监听器">
	@Override
	protected void addListener() {
		operateButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (isInOperation) {
					showMessage(CMPreferences.DuringExtractionPrompt);
					return;
				}
				if (allMusicFilePaths == null || allMusicFilePaths.equals("")) {
					showMessage("请先选择音乐源");
					return;
				}
				if (modelFileTextField.getText().equals(CMPreferences.NotSelectPath)) {
					showMessage("请先选择模型文件");
					return;
				}
				if (resultFileTextField.getText()
						.equals(CMPreferences.NotSelectPath)) {
					showMessage("请先选择要存储结果的文件");
					return;
				}

				Object threadCountObject = threadCountComboBox
						.getSelectedItem();
				int threadCount = (Integer) threadCountObject;

				List<File> fileList = new ArrayList<>();
				String[] filePaths = StringUtils.split(allMusicFilePaths, CMPreferences.SEPARATOR);
				for (String filePath : filePaths) {
					fileList.add(new File(filePath));
				}
				List<String> parameterList = new ArrayList<>();
				if (!trainParameterTextField.getText().trim().equals("")) {
					String[] parameters = trainParameterTextField.getText()
							.trim().split(" ");
					parameterList.addAll(Arrays.asList(parameters));
				}
				parameterList.add(CMPreferences.TMP_FEATURES_FILE);
				parameterList.add(modelFileTextField.getText());
				parameterList.add(resultFileTextField.getText());

				String[] svmParameters = (String[]) parameterList
						.toArray(new String[parameterList.size()]);

				final PredictParameters predictParameters = new PredictParameters(
						fileList, svmParameters, threadCount);

				Thread predictThread = new Thread(new Runnable() {

					@Override
					public void run() {
						statusLabel.setText(String.format("正在提取向量：%d/%d", 0,
								taskCount));
						isInOperation = true;
						long begin = System.nanoTime();

						ExtractorOpetratorForPredict extractorOpetratorForPredict = new ExtractorOpetratorForPredict(
								predictParameters);
						extractorOpetratorForPredict
								.addObserver(PredictorFrame.this);
						extractorOpetratorForPredict.start();

						long end = System.nanoTime();
						statusLabel.setText(String.format("预测完成，用时：%.2f 秒",
								(end - begin) / Math.pow(10, 9)));
						isInOperation = false;
					}
				});
				predictThread.setDaemon(true);
				predictThread.start();
			}
		});

		chooseFileSourceButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser(cmPreferences
						.getMusicFileChooserStartPath());
				boolean isFolder = chooseFolderRadioButton.isSelected();
				if (isFolder) {
					fileChooser
							.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					fileChooser.setMultiSelectionEnabled(false);
				} else {
					fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
					fileChooser.setMultiSelectionEnabled(true);
				}
				int option = fileChooser.showDialog(PredictorFrame.this, null);
				if (option == JFileChooser.APPROVE_OPTION) {
					List<File> mp3FileList = null;
					if (isFolder) {
						File dir = fileChooser.getSelectedFile();
						cmPreferences.setMusicFileChooserStartPath(dir
								.getAbsolutePath());
						mp3FileList = getSpecificFiles(dir, "mp3");
					} else {
						File[] files = fileChooser.getSelectedFiles();
						cmPreferences.setMusicFileChooserStartPath(files[0]
								.getAbsolutePath());
						mp3FileList = getSpecificFiles(files, "mp3");
					}
					cmPreferences.save();

					if (mp3FileList.isEmpty()) {
						showMessage("未选中任何 mp3 文件");
					} else {
						StringBuilder builder = new StringBuilder();
						for (File file : mp3FileList) {
							builder.append(file.getAbsolutePath());
							builder.append(CMPreferences.SEPARATOR);
						}
						allMusicFilePaths = builder.toString();
						musicSourceTextField.setText(allMusicFilePaths
								.substring(0, allMusicFilePaths.indexOf(CMPreferences.SEPARATOR))
								+ " ...");
						showMessage(allMusicFilePaths.replace(CMPreferences.SEPARATOR, '\n'),
								CMPreferences.SelectedMusicFiles);
						taskCount = mp3FileList.size();
						statusLabel.setText("等待预测："
								+ String.format("%d/%d", 0, taskCount));
					}
				}
			}
		});

		chooseModelFileButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String selectedFilePath = launchSelectFileDialog();
				if (!selectedFilePath.equals("")) {
					modelFileTextField.setText(selectedFilePath);
				}
			}
		});

		chooseResultFileButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String selectedFilePath = launchSelectFileDialog();
				if (!selectedFilePath.equals("")) {
					resultFileTextField.setText(selectedFilePath);
				}
			}
		});

		modelFileTextField.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				showMessage(modelFileTextField.getText(), "选中的模型文件");
			}

		});

		resultFileTextField.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				showMessage(resultFileTextField.getText(), "选择的保存结果的文件");
			}

		});

		musicSourceTextField.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				if (allMusicFilePaths == null || allMusicFilePaths.equals("")) {
					showMessage(musicSourceTextField.getText(), "选中的 Mp3 文件");
				} else {
					showMessage(allMusicFilePaths.replace(CMPreferences.SEPARATOR, '\n'),
							"选中的 Mp3 文件");
				}

			}

		});

		exitButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (isInOperation) {
					showMessage(CMPreferences.DuringExtractionPrompt);
				} else {
					PredictorFrame.this.setVisible(false);
					new ChooserFrame().setVisible(true);
					PredictorFrame.this.dispose();
				}
			}
		});

	}

	// </editor-fold>

	@Override
	protected void reflushUIAndData() {
		isInOperation = false;
		allMusicFilePaths = null;
		musicSourceTextField.setText(CMPreferences.NotSelectPath);
		resultFileTextField.setText(CMPreferences.NotSelectPath);
	}

	// <editor-fold defaultstate="collapsed" desc="界面组件">
	private JLabel chooseFileSourceLabel;
	private JRadioButton chooseFolderRadioButton;
	private JRadioButton chooseFilesRadioButton;
	private ButtonGroup fileSourceButtonGroup;
	private JButton chooseFileSourceButton;
	private JLabel musicSourceDescLabel;
	private JTextField musicSourceTextField;

	private JLabel threadCountDescLabel;
	private JComboBox<Integer> threadCountComboBox;

	private JLabel trainParameterDescLabel;
	private JTextField trainParameterTextField;

	private JLabel modelFileDescLabel;
	private JTextField modelFileTextField;
	private JButton chooseModelFileButton;

	private JLabel resultFileDescLabel;
	private JTextField resultFileTextField;
	private JButton chooseResultFileButton;
	// </editor-fold>
}
