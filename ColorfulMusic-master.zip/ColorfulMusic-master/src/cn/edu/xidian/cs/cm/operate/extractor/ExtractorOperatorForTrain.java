package cn.edu.xidian.cs.cm.operate.extractor;

import cn.edu.xidian.cs.cm.operate.util.CMPreferences;
import cn.edu.xidian.cs.cm.operate.util.DBConnectionProvider;
import cn.edu.xidian.cs.cm.operate.util.Music;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class ExtractorOperatorForTrain extends AbstractExtractorOperator {
    private static final Logger logger = Logger.getLogger(ExtractorOperatorForTrain.class);
    
    private final DBConnectionProvider provider = DBConnectionProvider.getInstance();
    private CMPreferences cmPreferences = CMPreferences.getInstance();
    private String PREPARED_INSERT_SQL;
    private int emotionInDB = 0; // TINYINT in MySQL

    public ExtractorOperatorForTrain(ExtractionParameters parameters){
        super(parameters);
        this.emotionInDB = parameters.getEmotionInDB();
        PREPARED_INSERT_SQL = "INSERT INTO " + cmPreferences.getDBTable() + " VALUES (null,?," + emotionInDB + ",?)";
    }
    
    @Override
    protected void doTask() {
        try ( Connection conn = provider.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(PREPARED_INSERT_SQL)){
            
            StringBuilder featuresBuilder = new StringBuilder();
            for (Music music : musicList){
                double[] features = music.getFeatures();
                if (features == null){
                    continue;
                }
                featuresBuilder.delete(0, featuresBuilder.length());
                for (double feature : features){
                    featuresBuilder.append(feature);
                    featuresBuilder.append("|");
                }
                pstmt.setString(1, music.getUrl().replace('\\', '/'));
                pstmt.setString(2, featuresBuilder.toString());
                
                try {
                    pstmt.executeUpdate();
                } catch (SQLException e) {
                    logger.error("数据插入数据库时出错");
                }
            }
            
        } catch (Exception e){
            logger.error("获取数据库连接时出错");
        }
    }

    @Override
    protected void updataFrameUI(Object arg) {
        setChanged();
        notifyObservers(arg); // notifyObservers()会调用clearChanged()方法
    }
}