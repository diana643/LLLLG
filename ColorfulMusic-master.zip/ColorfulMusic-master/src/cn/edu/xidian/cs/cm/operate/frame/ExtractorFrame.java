package cn.edu.xidian.cs.cm.operate.frame;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.AbstractButton;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import cn.edu.xidian.cs.cm.operate.extractor.ExtractionParameters;
import cn.edu.xidian.cs.cm.operate.extractor.ExtractorOperatorForTrain;
import cn.edu.xidian.cs.cm.operate.util.CMPreferences;
import cn.edu.xidian.cs.cm.operate.util.FeatureType;

/**
 * 提取界面，实现抽象操作界面和观察者接口
 * 抽象操作界面构建基本界面
 * 观察者接口用于在提取时更新进度（使用观察者模式）
 * @author ColorfulMusic Team
 */

public class ExtractorFrame extends AbstractOperateFrame implements Observer{
	private static final long serialVersionUID = 20141001L;
    private static final Logger logger = Logger.getLogger(ExtractorFrame.class);
    
    private int taskCount = 0;
    private String allMusicFilePaths;

    // <editor-fold defaultstate="collapsed" desc="接收提取器提取状态的通知，然后更新界面">
    @Override
    public void update(Observable o, Object arg) {
        if (o instanceof ExtractorOperatorForTrain){
            if (arg instanceof Integer){ // 如果 arg 是整型
                int finishedTaskCount = (Integer)arg;
                statusLabel.setText(CMPreferences.DuringExtraction + String.format("%d/%d", finishedTaskCount, taskCount));
            } else {
                logger.debug("通知参数设置错误");
            }
        }
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="初始化界面">
    @Override
    protected void initComponent(){
        
        chooseFileSourceLabel = new JLabel("请选择音乐源类型：");
        chooseFolderRadioButton = new JRadioButton("文件夹");
        chooseFolderRadioButton.setFocusPainted(false);
        chooseFilesRadioButton = new JRadioButton("若干文件");
        chooseFilesRadioButton.setFocusPainted(false);
        chooseFilesRadioButton.setSelected(true);
        fileSourceButtonGroup = new ButtonGroup();
        chooseFileSourceButton = new JButton("选择");
        fileSourceButtonGroup.add(chooseFolderRadioButton);
        fileSourceButtonGroup.add(chooseFilesRadioButton);
        
        threadCountDescLabel = new JLabel("开启的线程数：");
        Integer[] threadCountArray = new Integer[CPU_COUNT+1];
        for (int i = 0; i < threadCountArray.length; i++) {
			threadCountArray[i] = i + 1;
		}
        threadCountComboBox = new JComboBox<Integer>(threadCountArray);
        threadCountComboBox.setSelectedIndex(CPU_COUNT - 1);
        threadCountComboBox.setFocusable(false);
        
        Box box1 = Box.createHorizontalBox();
        box1.add(Box.createHorizontalStrut(margin));
        box1.add(chooseFileSourceLabel);
        box1.add(chooseFolderRadioButton);
        box1.add(chooseFilesRadioButton);
        box1.add(Box.createHorizontalStrut(margin));
        box1.add(threadCountDescLabel);
        box1.add(threadCountComboBox);
        box1.add(Box.createHorizontalStrut(margin));
        
        fileSourceDescLabel = new JLabel("预测音乐：");
        musicSourceTextField = new JTextField(CMPreferences.NotSelectPath);
        musicSourceTextField.setPreferredSize(new Dimension(270, 20));
        musicSourceTextField.setEditable(false);
        Box box2 = Box.createHorizontalBox();
        box2.add(Box.createHorizontalStrut(margin));
        box2.add(fileSourceDescLabel);
        box2.add(musicSourceTextField);
        box2.add(Box.createHorizontalStrut(padding));
        box2.add(chooseFileSourceButton);
        box2.add(Box.createHorizontalStrut(margin));
        
        emotionDescLabel = new JLabel("音频情感：");
        JRadioButton happyRadioButton = new JRadioButton("快乐");
        happyRadioButton.setSelected(true);
        happyRadioButton.setFocusPainted(false);
        JRadioButton peaceRadioButton = new JRadioButton("平静");
        peaceRadioButton.setFocusPainted(false);
        JRadioButton excitedRadioButton = new JRadioButton("振奋");
        excitedRadioButton.setFocusPainted(false);
        JRadioButton sadRadioRadioButton = new JRadioButton("忧伤");
        sadRadioRadioButton.setFocusPainted(false);
        JRadioButton unkonwnRadioButton = new JRadioButton("未知");
        unkonwnRadioButton.setFocusPainted(false);
        emotionButtonGroup = new ButtonGroup();
        emotionButtonGroup.add(happyRadioButton);
        emotionButtonGroup.add(peaceRadioButton);
        emotionButtonGroup.add(excitedRadioButton);
        emotionButtonGroup.add(sadRadioRadioButton);
        emotionButtonGroup.add(unkonwnRadioButton);
        
        Box box3 = Box.createHorizontalBox();
        box3.add(Box.createHorizontalStrut(margin));
        box3.add(emotionDescLabel);
        int box3Padding = 7;
        box3.add(happyRadioButton);
        box3.add(Box.createHorizontalStrut(box3Padding));
        box3.add(peaceRadioButton);
        box3.add(Box.createHorizontalStrut(box3Padding));
        box3.add(excitedRadioButton);
        box3.add(Box.createHorizontalStrut(box3Padding));
        box3.add(sadRadioRadioButton);
        box3.add(Box.createHorizontalStrut(box3Padding));
        box3.add(unkonwnRadioButton);
        box3.add(Box.createHorizontalGlue());
        
        featuresTypeDescLable = new JLabel("特征类型：");
        ssdTypeRadioButton = new JRadioButton("SSD"); // Statistical Spectrum Descriptor
        ssdTypeRadioButton.setSelected(true);
        ssdTypeRadioButton.setToolTipText("Statistical Spectrum Descriptor");
        ssdTypeRadioButton.setFocusable(false);
        rhTypeRadioButton = new JRadioButton("RH"); // Rhythm Histogram
        rhTypeRadioButton.setToolTipText("Rhythm Histogram");
        rhTypeRadioButton.setFocusable(false);
        rpTypeRadioButton = new JRadioButton("RP"); // Rhythm Patterns
        rpTypeRadioButton.setToolTipText("Rhythm Patterns");
        rpTypeRadioButton.setFocusable(false);
        featuresTypeButtonGroup = new ButtonGroup();
        featuresTypeButtonGroup.add(ssdTypeRadioButton);
        featuresTypeButtonGroup.add(rhTypeRadioButton);
        featuresTypeButtonGroup.add(rpTypeRadioButton);
        Box box4 = Box.createHorizontalBox();
        box4.add(Box.createHorizontalStrut(margin));
        box4.add(featuresTypeDescLable);
        int box4Padding = 9;
        box4.add(ssdTypeRadioButton);
        box4.add(Box.createHorizontalStrut(box4Padding));
        box4.add(rhTypeRadioButton);
        box4.add(Box.createHorizontalStrut(box4Padding));
        box4.add(rpTypeRadioButton);
        box4.add(Box.createHorizontalGlue());
        
        operateButton.setText("提取");
        JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.RIGHT, padding, 0));
        panel1.add(statusLabel);
        panel1.add(operateButton);
        panel1.add(exitButton);

        addComponentToMainBox(box1, box2, box3, box4, panel1);
        
        setTitle("提取");
        
        logger.info("启动 ExtractorFrame");
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="添加监听事件">
    @Override
    protected void addListener(){
        chooseFileSourceButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser(cmPreferences.getMusicFileChooserStartPath());
                boolean isFolder = chooseFolderRadioButton.isSelected();
                if (isFolder){
                    fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                    fileChooser.setMultiSelectionEnabled(false);
                } else {
                    fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
                    fileChooser.setMultiSelectionEnabled(true);
                }
                int option = fileChooser.showDialog(ExtractorFrame.this, null);
                if (option == JFileChooser.APPROVE_OPTION){
                    List<File> mp3FileList = null;
                    if (isFolder){
                        File dir = fileChooser.getSelectedFile();
                        cmPreferences.setMusicFileChooserStartPath(dir.getAbsolutePath());
                        mp3FileList = getSpecificFiles(dir, "mp3");
                    } else {
                        File[] files = fileChooser.getSelectedFiles();
                        cmPreferences.setMusicFileChooserStartPath(files[0].getParent());
                        mp3FileList = getSpecificFiles(files, "mp3");
                    }
                    cmPreferences.save();
                    
                    if (mp3FileList.isEmpty()){
                        showMessage("未选中任何 mp3 文件");
                    } else {
                        StringBuilder builder = new StringBuilder();
                        for (File file : mp3FileList){
                            builder.append(file.getAbsolutePath());
                            builder.append(CMPreferences.SEPARATOR);
                        }
                        allMusicFilePaths = builder.toString();
                        musicSourceTextField.setText(allMusicFilePaths.substring(0, allMusicFilePaths.indexOf(CMPreferences.SEPARATOR)) + " ...");
                        showMessage(allMusicFilePaths.replace(CMPreferences.SEPARATOR, '\n'), CMPreferences.SelectedMusicFiles);
                        taskCount = mp3FileList.size();
                        statusLabel.setText(CMPreferences.WaitingForExtraction + String.format("%d/%d", 0, taskCount));
                    }
                }
            }
        });
        
        operateButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (isInOperation){
                    showMessage(CMPreferences.DuringExtractionPrompt);
                    return;
                }
                // <editor-fold defaultstate="collapsed" desc="将从界面得到的数据打包成一个提取参数 ExtractionParameters">
                if (allMusicFilePaths == null || allMusicFilePaths.equals("")){
                    showMessage("请先选择音乐源");
                    return;
                }
                List<File> fileList = new ArrayList<>();
                String[] filePaths = StringUtils.split(allMusicFilePaths, CMPreferences.SEPARATOR);
                for (String filePath : filePaths){
                    fileList.add(new File(filePath)); // 获得提取时的音乐文件列表
                }
                
                Object threadCountObject = threadCountComboBox.getSelectedItem();
                int threadCount = (Integer)threadCountObject; // 获得提取时线程数
                
                int emotionInDB = 0; // 获得被提取音乐的情感
                String emotion = "" ;
                Enumeration<AbstractButton> emotionradioButtons = emotionButtonGroup.getElements();
                while (emotionradioButtons.hasMoreElements()){
                    JRadioButton radioButton = (JRadioButton)emotionradioButtons.nextElement();
                    if (radioButton.isSelected()){
                        emotion = radioButton.getText();
                        break;
                    }
                }
                switch (emotion) {
                    case "快乐":
                        emotionInDB = 1;
                        break;
                    case "平静":
                        emotionInDB = 2;
                        break;
                    case "振奋":
                        emotionInDB = 3;
                        break;
                    case "忧伤":
                        emotionInDB = 4;
                        break;
                }
                
                String featureType = "";
                FeatureType type = FeatureType.SSD;
                Enumeration<AbstractButton> featureTypeButtons = featuresTypeButtonGroup.getElements();
                while (featureTypeButtons.hasMoreElements()){
                    JRadioButton radioButton = (JRadioButton)featureTypeButtons.nextElement();
                    if (radioButton.isSelected()){
                    	featureType = radioButton.getText();
                        break;
                    }
                }
                switch (featureType) {
					case "SSD":
						type = FeatureType.SSD;
						break;
					case "RH":
						type = FeatureType.RH;
						break;
					case "RP":
						type = FeatureType.RP;
						break;
					default:
						break;	
				}
                // 打包 ExtractionParameters
                final ExtractionParameters cmOptions = new ExtractionParameters(fileList, threadCount, emotionInDB, type);
                // </editor-fold>
                
                Thread extractorThread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        
                        ExtractorOperatorForTrain extractorOperatorForTrain = new ExtractorOperatorForTrain(cmOptions);
                        extractorOperatorForTrain.addObserver(ExtractorFrame.this);
                        statusLabel.setText(CMPreferences.DuringExtraction + String.format("%d/%d", 0, taskCount));
                        isInOperation = true;
                        long begin = System.nanoTime();
                        
                        extractorOperatorForTrain.start(); // 开始提取
                        
                        long end = System.nanoTime();
                        statusLabel.setText(String.format("提取完成，用时：%.2f 秒", (end-begin)/Math.pow(10, 9)));
                        reflushUIAndData();
                    }
                });
                extractorThread.setDaemon(true);
                extractorThread.start();
            }
        });
        
        musicSourceTextField.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (allMusicFilePaths == null || allMusicFilePaths.equals("")){
                    showMessage(musicSourceTextField.getText(), CMPreferences.SelectedMusicFiles);
                } else {
                    showMessage(allMusicFilePaths.replace(CMPreferences.SEPARATOR, '\n'), CMPreferences.SelectedMusicFiles);
                }
            }
        });
        
        exitButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (isInOperation){
                    showMessage(CMPreferences.DuringExtractionPrompt);
                } else {
                    ExtractorFrame.this.setVisible(false);
                    new ChooserFrame().setVisible(true);
                    ExtractorFrame.this.dispose();
                }
            }
        });
        
    }
    // </editor-fold>

    @Override
    protected void reflushUIAndData() {
        allMusicFilePaths = null;
        isInOperation = false;
        musicSourceTextField.setText(CMPreferences.NotSelectPath);
    }
    
    // <editor-fold defaultstate="collapsed" desc="界面组件">
    private JLabel chooseFileSourceLabel;
    private JRadioButton chooseFolderRadioButton;
    private JRadioButton chooseFilesRadioButton;
    private ButtonGroup fileSourceButtonGroup;
    private JButton chooseFileSourceButton;
    private JLabel fileSourceDescLabel;
    private JTextField musicSourceTextField;
    
    private JLabel emotionDescLabel;
    private ButtonGroup emotionButtonGroup;
    
    private JLabel threadCountDescLabel;
    private JComboBox<Integer> threadCountComboBox;
    
    private JLabel featuresTypeDescLable;
    private JRadioButton ssdTypeRadioButton; 
    private JRadioButton rhTypeRadioButton;
    private JRadioButton rpTypeRadioButton;
    private ButtonGroup featuresTypeButtonGroup;
    // </editor-fold>
    
}
