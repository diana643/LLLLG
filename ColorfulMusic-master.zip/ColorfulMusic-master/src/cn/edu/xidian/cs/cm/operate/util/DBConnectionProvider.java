package cn.edu.xidian.cs.cm.operate.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.apache.log4j.Logger;

/**
 * 为程序提供数据库的连接<br>
 * 使用单例模式，保证 DBConnectionProvider 在一次运行时只有一个实例
 * @author ColorfulMusic Team
 *
 */
public class DBConnectionProvider {
    private static final Logger logger = Logger.getLogger(DBConnectionProvider.class);
	CMPreferences cmPreferences = CMPreferences.getInstance();
    
    private final String JDBC_DRIVER;
    private final String DB_URL;
    private final String DB_USER;
    private final String DB_PASSWORD;
   
    private static class DBConnectionProviderClass{
    	private static final DBConnectionProvider instance = new DBConnectionProvider();
    }
    public static DBConnectionProvider getInstance(){
    	return DBConnectionProviderClass.instance;
    }
    private DBConnectionProvider() {
        JDBC_DRIVER = cmPreferences.getDBDriver();
        DB_URL = cmPreferences.getDBUrl();
        DB_USER = cmPreferences.getDBUserName();
        DB_PASSWORD = cmPreferences.getDBPassword();
        logger.info("数据库链接：" + DB_URL);
        try {
            Class.forName(JDBC_DRIVER);
            logger.info("成功加载数据库驱动");
        } catch (ClassNotFoundException ex) {
            logger.error("DBConnectionProvider 连接数据库时出错");
        }
    }
    /**
     * 获得一个数据库连接
     * @return 数据库连接
     * @throws SQLException
     */
    public Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        return conn;
    }
}
