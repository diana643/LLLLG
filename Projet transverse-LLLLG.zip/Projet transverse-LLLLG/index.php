<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!--        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">-->


        <!--For Plugins external css-->
        <link rel="stylesheet" href="assets/css/plugins.css" />
		<link rel="stylesheet" href="assets/css/magnific-popup.css">
		
        <link rel="stylesheet" href="assets/css/nexa-web-font.css" />
        <link rel="stylesheet" href="assets/css/opensans-web-font.css" />

        <!--Theme custom css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!--Theme Responsive css-->
        <link rel="stylesheet" href="assets/css/responsive.css" />

        <script src="assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		
		<div class='preloader'><div class='loaded'>&nbsp;</div></div>
		
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">VisioMusiqueClassique</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="index.html">Accueil</a></li>
                        <li><a href="equipe.html">Notre équipe</a></li>
                        <li><a href="contact.html">Nous contact</a></li>
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>

        <!--Home page style-->
        <header id="home" class="home" >
			<div class="overlay sections" >
				<div class="container">
					
					<div class="row">
						<div class="wrapper margin-top-20">
							<div class="col-md-6 col-md-offset-3">
								
								<div class="home-details text-center" >
									<div class="logopic" > <!-- logo -->
										<img src="assets/images/logo1.png" alt="Logo Image" height="200" width="200" />
									</div>
										
									<div class="home-title text-center" style="font-size: 50px;">
										<h3>Visio Musique Classique</h3>
									</div>
									
									<!-- <div class="scroll-down">
										<h5>AITES DÉFILER POUR VOIR PLUS</h5>
									</div> -->
									<i class="fa fa-angle-double-down"></i>
								</div>
									
							</div>
						</div>
					</div>
				</div>
			</div>
        </header>

        <!-- Sections -->
        <section id="about" class="about sections">
            <div class="container">

                <!-- Example row of columns -->
                <div class="row">
                    <div class="wrapper">
					
                    	<div class="col-md-6">
                    		<div class="about-photo" style="margin-top: 50px">
								<img src="assets/images/colorEmotion.png" alt="About Image" height="400" width="400"/>
							</div>
                    	</div>
						
						<div class="col-md-6">
                    		<div class="heading about-content">
								<h3>Notre philosophie</h3>
								<p>“Visio-MusiqueClassique” est une application en ligne qu'on peut écouter les musiques classiques on veut. Selon ses appartenances, comme la mélodie, le rythme et le style que les musique montre, on cherche une ou plusieurs images sur internet et les exhibe. Les images sont les dessins, les œuvres connues ou les photos populaires récemment. </p>
								<p>Ecouter de la musique tout en regardant des images, et de combiner l'audition et la vision.</p>
							</div>
							<!-- <i class="fa fa-angle-double-down"></i> -->
                    	</div>
						
						
						
                    </div>
                </div>
				
				<!-- <div class="scroll-down">
					<h5>keep scrolling, there is still more to come.</h5>
					<i class="fa fa-angle-double-down"></i>
				</div> -->
				
            </div> <!-- /container -->       
        </section>
		
		
		<!-- Sections -->
        <section id="portfolio" class="portfolio">
			<div class="overlay sections">
				<div class="container">
				
					<div class="heading text-center">
						<div class="title">
							<h3>LES MUSIQUE CLASSIQUE</h3>
						</div>
					</div>
					
					<!-- Example row of columns -->
					
					<!-- <div class="row"> -->
						<div class="portfolio-wrapper" style="margin-left: 50px;">
							<div class="portfolio-item">
							
								<div class="portfolio-details">
									<a href="musique1.php" class="portfolio-img"><img src="assets/images/portfolio/1.jpg" alt="Portfolio" /></a>
								</div>
							</div>
								
							<div class="portfolio-item">
							
								<div class="portfolio-details">
									<a href="assets/images/portfolio/2.png" class="portfolio-img"><img src="assets/images/portfolio/2.jpg" alt="Portfolio" /></a>
								</div>
								
							</div>

							<div class="portfolio-item">
							
								<div class="portfolio-details">
									<a href="assets/images/portfolio/3.png" class="portfolio-img"><img src="assets/images/portfolio/3.jpg" alt="Portfolio" /></a>
								</div>
								
							</div>

							<!-- <div class="portfolio-item">
							
								<div class="portfolio-details">
									<a href="assets/images/portfolio/4.png" class="portfolio-img"><img src="assets/images/portfolio/4.jpg" alt="Portfolio" /></a>
								</div>
								
							</div> -->

							<div class="portfolio-item">
							
								<div class="portfolio-details">
									<a href="assets/images/portfolio/5.png" class="portfolio-img"><img src="assets/images/portfolio/5.jpg" alt="Portfolio" /></a>
								</div>
								
							</div>
							
							<!-- <div class="portfolio-item">
							
								<div class="portfolio-details">
									<a href="assets/images/portfolio/6.png" class="portfolio-img"><img src="assets/images/portfolio/6.jpg" alt="Portfolio" /></a>
								</div>
								
							</div> -->
						</br>
							<div class="portfolio-item">
							
								<div class="portfolio-details">
									<a href="assets/images/portfolio/7.png" class="portfolio-img"><img src="assets/images/portfolio/7.jpg" alt="Portfolio" /></a>
								</div>
								
							</div>
							<!-- <div class="portfolio-item">
							
								<div class="portfolio-details">
									<a href="assets/images/portfolio/8.png" class="portfolio-img"><img src="assets/images/portfolio/8.jpg" alt="Portfolio" /></a>
								</div>
								
							</div> -->
							<div class="portfolio-item">
							
								<div class="portfolio-details">
									<a href="assets/images/portfolio/9.png" class="portfolio-img"><img src="assets/images/portfolio/9.jpg" alt="Portfolio" /></a>
								</div>
								
							</div>
							<div class="portfolio-item">
							
								<div class="portfolio-details">
									<a href="assets/images/portfolio/10.png" class="portfolio-img"><img src="assets/images/portfolio/10.jpg" alt="Portfolio" /></a>
								</div>
								
							</div>
							<div class="portfolio-item">
							
								<div class="portfolio-details">
									<a href="assets/images/portfolio/11.png" class="portfolio-img"><img src="assets/images/portfolio/11.jpg" alt="Portfolio" /></a>
								</div>
								
							</div>
							<i class="fa fa-angle-double-down"></i>
								
							
							<!-- <div class="scroll-down">
								<h5>Do you want to see it with your own eyes? Scroll!</h5>
								<a href="#contact"></a>
							</div> -->
							
						
					</div>
				</div> <!-- /container -->
			</div>	
        </section>
		
		<!-- <section id="contact" class="contact sections">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3">
						<div class="contact-details text-center">
							<div><img  hight="100" width="100" src="assets/images/logo.jpg"></div>

							<div class="contact-category">
								<div class="mail">
									<h4>Mail :</h4>
									<h2>Jason@wood.com</h2>
								</div>
							</div>
							
							<div class="contact-category">
								<div class="phone">
									<h4>Phone :</h4>
									<h5>00 11 22 33 44 55 66</h5>
								</div>
							</div>
							
							<div class="contact-category">
								<div class="social">
									<h4>Social Media :</h4>
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-instagram"></i></a>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</section> -->


        <!--Footer-->
        <footer id="footer" class="footer">
            <div class="container">
            	<div class="row">
            		<div class="col-md-12">
            			<div class="copyright text-center">
            				<div><img  hight="100" width="100" src="assets/images/logo1.png"></div>

            				<p>LLLLG <!-- <i class="fa fa-heart"></i> --> </br>EFREI PAIRS Promotion_2020</p>
            			</div>
            		</div>
            	</div>
            </div>
        </footer>


        <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="assets/js/vendor/bootstrap.min.js"></script>

        <script src="assets/js/plugins.js"></script>
		<script src="assets/js/jquery.magnific-popup.js"></script>

		 
        <script src="assets/js/main.js"></script>
    </body>
</html>
