<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!--        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">-->


        <!--For Plugins external css-->
        <link rel="stylesheet" href="assets/css/plugins.css" />
		<link rel="stylesheet" href="assets/css/magnific-popup.css">
		
        <link rel="stylesheet" href="assets/css/nexa-web-font.css" />
        <link rel="stylesheet" href="assets/css/opensans-web-font.css" />

        <!--Theme custom css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!--Theme Responsive css-->
        <link rel="stylesheet" href="assets/css/responsive.css" />

        <script src="assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
<body style="background: url(assets/images/header_bg.jpg) no-repeat top fixed; width:100%; ">

         <nav class="navbar navbar-default navbar-fixed-top" ">
            <div class="container">
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <div class="col-md-6" style="margin-top: 5px">
                <img src="assets/images/logo1.png" alt="Logo Image" width="75" height="75">
                <embed height="60" width="300" src="assets/audios/1.mp3" autostart="false" padding-top="20">
            </div>
        
            <ul class="nav navbar-nav navbar-right">
                <li class="active"><a href="index.php">Accueil</a></li>
                <li><a href="equipe.html">Notre équipe</a></li>
                <li><a href="contact.html">Nous contact</a></li>
            </ul>
        </div>
</div>
</nav>

<div class="about sections">
    <div class="container">
        <!-- Example row of columns -->
        <div >
            <div >
            
                <div style="height: 390px">
                    <div class="about-photo" style="margin-top: 50px; margin-left: 0px">
                </div>     
                <div style="margin-top: 5px">
                    <div>
                        
                        <img src="assets/images/portfolio/1.jpg" width="400" margin-right="100">
                        
                        <img src="assets/images/emotionpic/warm.jpg" width="705" margin-right="100">
                    </div>
                </div>                  
                <!-- <div>
                    <div style="margin-right: 10px">
                        <img src="assets/images/emotionpic/warm.jpg" width="400">
                    </div>
                </div> -->
                
            </div>
        </div>
                
                <!-- <div class="scroll-down">
                    <h5>keep scrolling, there is still more to come.</h5>
                    <i class="fa fa-angle-double-down"></i>
                </div> -->
                
            </div> <!-- /container -->       
        </div>




    </body>